from typing import Union, Tuple, Generator, Optional
from nbt import nbt
from .biome import Biome
from .block import Block, OldBlock
from .region import Region
from .errors import OutOfBoundsCoordinates, ChunkNotFound
from .versions import VERSION_21w43a, VERSION_20w17a, VERSION_19w36a, VERSION_17w47a, VERSION_PRE_15w32a


def bin_append(a, b, length=None):
    """
    Appends number a to the left of b
    bin_append(0b1, 0b10) = 0b110
    """
    length = length or b.bit_length()
    return (a << length) | b


def nibble(byte_array, index):
    value = byte_array[index // 2]
    if index % 2:
        return value >> 4
    else:
        return value & 0b1111


def _palette_from_section(section: nbt.TAG_Compound) -> nbt.TAG_List:
    if 'block_states' in section:
        return section["block_states"]["palette"]
    else:
        return section["Palette"]


def _states_from_section(section: nbt.TAG_Compound) -> list:
        # BlockStates is an array of 64 bit numbers
        # that holds the blocks index on the palette list
        if 'block_states' in section:
            states = section['block_states']['data']
        else:
            states = section['BlockStates']

        # makes sure the number is unsigned
        # by adding 2^64

        return [state if state >= 0 else states + 2 ** 64 
            for state in states.value]


def _section_height_range(version: Optional[int]) -> range:
    if version > VERSION_17w47a:
        return range(-4, 20)
    else:
        return range(16)


class Chunk:
    """
    Represents a chunk from a ``.mca`` file.

    Note that this is read only.

    Attributes
    ----------
    x: :class:`int`
        Chunk's X position
    z: :class:`int`
        Chunk's Z position
    version: :class:`int`
        Version of the chunk NBT structure
    data: :class:`nbt.TAG_Compound`
        Raw NBT data of the chunk
    tile_entities: :class:`nbt.TAG_Compound`
        ``self.data['TileEntities']`` as an attribute for easier use
    """

    __slots__ = ("version", "data", "x", "z", "tile_entities")

    def __init__(self, nbt_data: nbt.NBTFile):
        try:
            self.version = nbt_data["DataVersion"].value
        except KeyError:
            # Version is pre-1.9 snapshot 15w32a, so world does not have a Data Version.
            # See https://minecraft.wiki/w/Data_version
            self.version = VERSION_PRE_15w32a

        if self.version >= VERSION_21w43a:
            self.data = nbt_data
            self.tile_entities = self.data["block_entities"]
        else:
            self.data = nbt_data["Level"]
            self.tile_entities = self.data["TileEntities"]
        self.x = self.data["xPos"].value
        self.z = self.data["zPos"].value

    def get_section(self, y: int) -> nbt.TAG_Compound:
        """
        Returns the section at given y index
        can also return nothing if section is missing, aka it's empty

        Parameters
        ----------
        y
            Section Y index

        Raises
        ------
        anvil.OutOfBoundsCoordinates
            If Y is not in range of 0 to 15
        """
        section_range = _section_height_range(self.version)
        if y not in section_range:
            raise OutOfBoundsCoordinates(f"Y ({y!r}) must be in range of "
                f"{section_range.start} to {section_range.stop}")

        if 'sections' in self.data:
            sections = self.data["sections"]
        else:
            try:
                sections = self.data["Sections"]
            except KeyError:
                return None

        for section in sections:
            if section["Y"].value == y:
                return section

    def get_palette(self, section: Union[int, nbt.TAG_Compound]) -> Tuple[Block]:
        """
        Returns the block palette for given section

        Parameters
        ----------
        section
            Either a section NBT tag or an index


        :rtype: Tuple[:class:`anvil.Block`]
        """
        if isinstance(section, int):
            section = self.get_section(section)
        if section is None:
            return
        palette = _palette_from_section(section)
        return tuple(Block.from_palette(i) for i in palette)

    def get_biome(self, x: int, y: int, z: int) -> Biome:
        """
        Returns the biome in the given coordinates

        Parameters
        ----------
        int x, y, z
            Biome's coordinates in the chunk

        Raises
        ------
        anvil.OutOfBoundCoordidnates
            If X, Y or Z are not in the proper range

        :rtype: :class:`anvil.Biome`
        """
        section_range = _section_height_range(self.version)
        if x not in range(16):
            raise OutOfBoundsCoordinates(f"X ({x!r}) must be in range of 0 to 15")
        if z not in range(16):
            raise OutOfBoundsCoordinates(f"Z ({z!r}) must be in range of 0 to 15")
        if y // 16 not in section_range:
            raise OutOfBoundsCoordinates(f"Y ({y!r}) must be in range of "
                f"{section_range.start * 16} to {section_range.stop * 16 - 1}")
        
        if 'Biomes' not in self.data:
            # Each biome index refers to a 4x4x4 volumes here so we do integer division by 4
            section = self.get_section(y // 16)
            biomes = section['biomes']
            biomes_palette = biomes['palette']
            if 'data' in biomes:
                biomes = biomes['data']
            else:
                # When there is only one biome in the section of the palette 'data'
                # is not present
                return Biome.from_name(biomes_palette[0].value)


            index = ((y % 16) // 4) * 16 + (z // 4) * 4 + (x // 4)
            bits = (len(biomes_palette) - 1).bit_length()
            state = index * bits // 64
            data = biomes[state]

            # shift the number to the right to remove the left over bits
            # and shift so the i'th biome is the first one
            shifted_data = data >> ((bits * index) % 64)

            # if there aren't enough bits it means the rest are in the next number
            if 64 - ((bits * index) % 64) < bits:
                data = biomes[state + 1]

                # get how many bits are from a palette index of the next biome
                leftover = (bits - ((state + 1) * 64 % bits)) % bits

                # Make sure to keep the length of the bits in the first state
                # Example: bits is 5, and leftover is 3
                # Next state                Current state (already shifted)
                # 0b101010110101101010010   0b01
                # will result in bin_append(0b010, 0b01, 2) = 0b01001
                shifted_data = bin_append(
                    data & 2**leftover - 1, shifted_data, bits - leftover
                )

            palette_id = shifted_data & 2**bits - 1
            return Biome.from_name(biomes_palette[palette_id].value)

        else:
            biomes = self.data["Biomes"]
            if self.version < VERSION_19w36a:
                # Each biome index refers to a column stored Z then X.
                index = z * 16 + x
            else:
                # https://minecraft.wiki/w/Java_Edition_19w36a
                # Get index on the biome list with the order YZX
                # Each biome index refers to a 4x4 areas here so we do integer division by 4
                index = (y // 4) * 4 * 4 + (z // 4) * 4 + (x // 4)
            biome_id = biomes[index]
            return Biome.from_numeric_id(biome_id)

    def get_block(
        self,
        x: int,
        y: int,
        z: int,
        section: Union[int, nbt.TAG_Compound] = None,
        force_new: bool = False,
    ) -> Union[Block, OldBlock]:
        """
        Returns the block in the given coordinates

        Parameters
        ----------
        int x, y, z
            Block's coordinates in the chunk
        section : int
            Either a section NBT tag or an index. If no section is given,
            assume Y is global and use it for getting the section.
        force_new
            Always returns an instance of Block if True, otherwise returns type OldBlock for pre-1.13 versions.
            Defaults to False

        Raises
        ------
        anvil.OutOfBoundCoordidnates
            If X, Y or Z are not in the proper range

        :rtype: :class:`anvil.Block`
        """
        if x not in range(16):
            raise OutOfBoundsCoordinates(f"X ({x!r}) must be in range of 0 to 15")
        if z not in range(16):
            raise OutOfBoundsCoordinates(f"Z ({z!r}) must be in range of 0 to 15")
        section_range = _section_height_range(self.version)
        if y // 16 not in section_range:
            raise OutOfBoundsCoordinates(f"Y ({y!r}) must be in range of "
                f"{section_range.start * 16} to {section_range.stop * 16 - 1}")

        if section is None:
            section = self.get_section(y // 16)
            # global Y to section Y
            y %= 16

        if self.version < VERSION_17w47a:
            # Explained in depth here https://minecraft.wiki/w/index.php?title=Chunk_format&oldid=1153403#Block_format

            if section is None or "Blocks" not in section:
                if force_new:
                    return Block.from_name("minecraft:air")
                else:
                    return OldBlock(0)

            index = y * 16 * 16 + z * 16 + x

            block_id = section["Blocks"][index]
            if "Add" in section:
                block_id += nibble(section["Add"], index) << 8

            block_data = nibble(section["Data"], index)

            block = OldBlock(block_id, block_data)
            if force_new:
                return block.convert()
            else:
                return block

        # If its an empty section its most likely an air block
        if section is None:
            return Block.from_name("minecraft:air")
        try:
            states = _states_from_section(section)
        except KeyError:
            return Block.from_name("minecraft:air")
            
        # Number of bits each block is on BlockStates
        # Cannot be lower than 4
        palette = _palette_from_section(section)

        bits = max((len(palette) - 1).bit_length(), 4)

        # Get index on the block list with the order YZX
        index = y * 16 * 16 + z * 16 + x
        # in 20w17a and newer blocks cannot occupy more than one element on the BlockStates array
        stretches = self.version < VERSION_20w17a

        # get location in the BlockStates array via the index
        if stretches:
            state = index * bits // 64
        else:
            state = index // (64 // bits)

        data = states[state]

        if stretches:
            # shift the number to the right to remove the left over bits
            # and shift so the i'th block is the first one
            shifted_data = data >> ((bits * index) % 64)
        else:
            shifted_data = data >> (index % (64 // bits) * bits)

        # if there aren't enough bits it means the rest are in the next number
        if stretches and 64 - ((bits * index) % 64) < bits:
            data = states[state + 1]

            # get how many bits are from a palette index of the next block
            leftover = (bits - ((state + 1) * 64 % bits)) % bits

            # Make sure to keep the length of the bits in the first state
            # Example: bits is 5, and leftover is 3
            # Next state                Current state (already shifted)
            # 0b101010110101101010010   0b01
            # will result in bin_append(0b010, 0b01, 2) = 0b01001
            shifted_data = bin_append(
                data & 2**leftover - 1, shifted_data, bits - leftover
            )

        # get `bits` least significant bits
        # which are the palette index
        palette_id = shifted_data & 2**bits - 1
        return Block.from_palette(palette[palette_id])

    def stream_blocks(
        self,
        index: int = 0,
        section: Union[int, nbt.TAG_Compound] = None,
        force_new: bool = False,
    ) -> Generator[Block, None, None]:
        """
        Returns a generator for all the blocks in given section

        Parameters
        ----------
        index
            At what block to start from.

            To get an index from (x, y, z), simply do:

            ``y * 256 + z * 16 + x``
        section
            Either a Y index or a section NBT tag.
        force_new
            Always returns an instance of Block if True, otherwise returns type OldBlock for pre-1.13 versions.
            Defaults to False

        Raises
        ------
        anvil.OutOfBoundCoordidnates
            If `section` is not in the range of 0 to 15

        Yields
        ------
        :class:`anvil.Block`
        """

        if isinstance(section, int):
            section_range = _section_height_range(self.version)
            if section not in section_range:
                raise OutOfBoundsCoordinates(f"section ({section!r}) must be in range of "
                    f"{section_range.start} to {section_range.stop}")

        # For better understanding of this code, read get_block()'s source

        if section is None or isinstance(section, int):
            section = self.get_section(section or 0)

        if self.version < VERSION_17w47a:
            if section is None or "Blocks" not in section:
                air = Block.from_name("minecraft:air") if force_new else OldBlock(0)
                for _ in range(4096):
                    yield air
                return

            while index < 4096:
                block_id = section["Blocks"][index]
                if "Add" in section:
                    block_id += nibble(section["Add"], index) << 8

                block_data = nibble(section["Data"], index)

                block = OldBlock(block_id, block_data)
                if force_new:
                    yield block.convert()
                else:
                    yield block

                index += 1
            return

        air = Block.from_name("minecraft:air")
        if section is None:
            for _ in range(4096):
                yield air
            return
        try:
            states = _states_from_section(section)
        except KeyError:
            for _ in range(4096):
                yield air
            return

        palette = _palette_from_section(section)
        bits = max((len(palette) - 1).bit_length(), 4)

        stretches = self.version < VERSION_20w17a

        if stretches:
            state = index * bits // 64
        else:
            state = index // (64 // bits)

        data = states[state]

        bits_mask = 2**bits - 1

        if stretches:
            offset = (bits * index) % 64
        else:
            offset = index % (64 // bits) * bits

        data_len = 64 - offset
        data >>= offset

        while index < 4096:
            if data_len < bits:
                state += 1
                new_data = states[state]

                if stretches:
                    leftover = data_len
                    data_len += 64

                    data = bin_append(new_data, data, leftover)
                else:
                    data = new_data
                    data_len = 64

            palette_id = data & bits_mask
            yield Block.from_palette(palette[palette_id])

            index += 1
            data >>= bits
            data_len -= bits

    def stream_chunk(
        self, index: int = 0, section: Union[int, nbt.TAG_Compound] = None
    ) -> Generator[Block, None, None]:
        """
        Returns a generator for all the blocks in the chunk

        This is a helper function that runs Chunk.stream_blocks from section 0 to 15

        Yields
        ------
        :class:`anvil.Block`
        """
        for section in _section_height_range(self.version):
            for block in self.stream_blocks(section=section):
                yield block

    # Block modification methods
    def set_block(self, block: Block, x: int, y: int, z: int) -> None:
        """
        Sets a block at given coordinates in the chunk.
        Optimized for Minecraft 1.21.1 only.
        
        Parameters
        ----------
        block : Block
            The block to set
        int x, z
            In range of 0 to 15
        int y
            Global Y coordinate
            
        Raises
        ------
        OutOfBoundsCoordinates
            If coordinates are out of bounds
        """
        # Need Optimisation
        if not (0 <= x < 16):
            raise OutOfBoundsCoordinates(f"X ({x!r}) must be in range of 0 to 15")
        if not (0 <= z < 16):
            raise OutOfBoundsCoordinates(f"Z ({z!r}) must be in range of 0 to 15")
        
        section_range = _section_height_range(self.version)
        section_y = y // 16
        if section_y not in section_range:
            raise OutOfBoundsCoordinates(f"Y ({y!r}) must be in range of "
                f"{section_range.start * 16} to {section_range.stop * 16 - 1}")
        
        section = self.get_section(section_y)
        if section is None:
            section = self._create_section(section_y)
        
        local_y = y % 16
        self._set_block_in_section(section, block, x, local_y, z)
    
    def _create_section(self, section_y: int) -> nbt.TAG_Compound:
        """Create a new empty section."""
        section = nbt.TAG_Compound()
        section.tags.append(nbt.TAG_Byte(name='Y', value=section_y))
        
        # Create initial palette with air block
        palette = nbt.TAG_List(name='Palette', type=nbt.TAG_Compound)
        air = nbt.TAG_Compound()
        air.tags.append(nbt.TAG_String(name='Name', value='minecraft:air'))
        palette.tags.append(air)
        section.tags.append(palette)
        
        # Initialize block states with minimum bit size
        bits = 4
        total_bits = 4096 * bits  # 16x16x16 blocks
        states_count = (total_bits + 63) // 64  # Number of longs needed
        block_states = nbt.TAG_Long_Array(name='BlockStates')
        block_states.value = [0] * states_count
        section.tags.append(block_states)
        
        # Add section to the chunk's section list
        if self.version >= VERSION_21w43a:
            if 'sections' not in self.data:
                sections = nbt.TAG_List(name='sections', type=nbt.TAG_Compound)
                self.data.tags.append(sections)
            self.data['sections'].tags.append(section)
        else:
            if 'Sections' not in self.data:
                sections = nbt.TAG_List(name='Sections', type=nbt.TAG_Compound)
                self.data.tags.append(sections)
            self.data['Sections'].tags.append(section)
        
        return section
    
    def _set_block_in_section(self, section: nbt.TAG_Compound, block: Block, 
                              x: int, y: int, z: int) -> None:
        """Set block in a section (modern format 1.21.1+)."""
        palette = _palette_from_section(section)
        
        # Find block in existing palette or add it
        block_index = None
        block_name = block.name()
        for i, palette_block in enumerate(palette):
            if palette_block['Name'].value == block_name:
                pal_props = palette_block.get('Properties')
                if self._props_match(pal_props, block.properties):
                    block_index = i
                    break
        
        # Add block to palette if not found
        if block_index is None:
            block_index = len(palette)
            new_block = nbt.TAG_Compound()
            new_block.tags.append(nbt.TAG_String(name='Name', value=block_name))
            
            # Add properties if block has any
            if block.properties:
                props = nbt.TAG_Compound()
                props.name = 'Properties'
                for k, v in block.properties.items():
                    props.tags.append(nbt.TAG_String(name=k, value=str(v)))
                new_block.tags.append(props)
            
            palette.tags.append(new_block)
    
        # Get or create block states array
        states = None
        blockstates_tag = None
        
        if 'block_states' in section:
            blockstates_tag = section['block_states']
            if 'data' in blockstates_tag:
                states = blockstates_tag['data'].value
            elif hasattr(blockstates_tag, 'value') and blockstates_tag.value is not None:
                states = blockstates_tag.value
        elif 'BlockStates' in section:
            blockstates_tag = section['BlockStates']
            # Legacy version (pre 1.13)
            if hasattr(blockstates_tag, 'value'):
                states = blockstates_tag.value
        
        # Initialize states array if it doesn't exist
        if states is None:
            bits = max((len(palette) - 1).bit_length(), 4)
            total_bits = 4096 * bits
            states_count = (total_bits + 63) // 64 
            states = [0] * states_count
            
            # Handle different version formats
            if self.version >= VERSION_21w43a:
                if 'block_states' not in section:
                    block_states_container = nbt.TAG_Compound(name='block_states')
                    block_states_tag = nbt.TAG_Long_Array(name='data')
                    block_states_tag.value = states
                    block_states_container.tags.append(block_states_tag)
                    section.tags.append(block_states_container)
                else:
                    block_states_container = section['block_states']
                    if 'data' in block_states_container:
                        block_states_tag = block_states_container['data']
                        block_states_tag.value = states
                    else:
                        block_states_tag = nbt.TAG_Long_Array(name='data')
                        block_states_tag.value = states
                        block_states_container.tags.append(block_states_tag)
            else:
                new_blockstates = nbt.TAG_Long_Array(name='BlockStates')
                new_blockstates.value = states
                section.tags.append(new_blockstates)
        else:
            bits = max((len(palette) - 1).bit_length(), 4)
        
        # Calculate block position in the states array (YZX order)
        index = y * 256 + z * 16 + x
        
        # In 1.21.1, blocks don't span across multiple longs
        state_idx = index // (64 // bits)
        offset = (index % (64 // bits)) * bits
        
        # Extend states array if needed
        if state_idx >= len(states):
            states.extend([0] * (state_idx - len(states) + 1))
        
        # Set the block index in the states array
        mask = (1 << bits) - 1
        states[state_idx] &= ~(mask << offset)  # Clear old value
        states[state_idx] |= (block_index & mask) << offset  # Set new value
    
    def _props_match(self, nbt_props, block_props: dict) -> bool:
        """Check if properties match."""
        if not nbt_props and not block_props:
            return True
        if not nbt_props or not block_props:
            return False
        for k, v in block_props.items():
            if k not in nbt_props or nbt_props[k].value != str(v):
                return False
        return True
    
    def save(self, file_path: str) -> None:
        """
        Save the modified chunk to a region file.
        
        Parameters
        ----------
        file_path : str
            Path to the region file
        """
        region = Region.from_file(file_path)
        region.save_chunk(self, file_path)

    def get_tile_entity(self, x: int, y: int, z: int) -> Optional[nbt.TAG_Compound]:
        """
        Returns the tile entity at given coordinates, or ``None`` if there isn't a tile entity

        To iterate through all tile entities in the chunk, use :class:`Chunk.tile_entities`
        """
        for tile_entity in self.tile_entities:
            t_x, t_y, t_z = [tile_entity[k].value for k in "xyz"]
            if x == t_x and y == t_y and z == t_z:
                return tile_entity

    @classmethod
    def from_region(cls, region: Union[str, Region], chunk_x: int, chunk_z: int):
        """
        Creates a new chunk from region and the chunk's X and Z

        Parameters
        ----------
        region
            Either a :class:`anvil.Region` or a region file name (like ``r.0.0.mca``)

        Raises
        ----------
        anvil.ChunkNotFound
            If a chunk is outside this region or hasn't been generated yet
        """
        if isinstance(region, str):
            print("TEST1010")
            region = Region.from_file(region)
        nbt_data = region.chunk_data(chunk_x, chunk_z)
        if nbt_data is None:
            raise ChunkNotFound(f"Could not find chunk ({chunk_x}, {chunk_z})")
        return cls(nbt_data)
    
    def replace_block_at(self, x: int, y: int, z: int, new_block: Union[str, Block]) -> bool:
        """
        Replace a single block at specific coordinates.
        
        Parameters
        ----------
        x : int
            X coordinate (0-15)
        y : int
            Global Y coordinate
        z : int
            Z coordinate (0-15)
        new_block : Union[str, Block]
            The replacement block (either a block name like "minecraft:dirt" or a Block object)
        
        Returns
        -------
        bool
            True if the block was replaced, False otherwise
        
        Example
        -------
        >>> chunk.replace_block_at(5, 64, 10, "minecraft:diamond_block")
        >>> chunk.replace_block_at(5, 64, 10, Block.from_name("minecraft:stone"))
        """
        # Convert string to Block object if needed
        if isinstance(new_block, str):
            new_block = Block.from_name(new_block)
        
        try:
            self.set_block(new_block, x, y, z)
            return True
        except OutOfBoundsCoordinates:
            return False

    def replace_blocks(self, old_block: Union[str, Block], new_block: Union[str, Block]) -> int:
        """
        Replace all occurrences of a specific block type with another block type in the chunk.
        
        Parameters
        ----------
        old_block : Union[str, Block]
            The block to replace (either a block name like "minecraft:stone" or a Block object)
        new_block : Union[str, Block]
            The replacement block (either a block name like "minecraft:dirt" or a Block object)
        
        Returns
        -------
        int
            The number of blocks replaced
        
        Example
        -------
        >>> chunk.replace_blocks("minecraft:stone", "minecraft:dirt")
        >>> chunk.replace_blocks(Block.from_name("minecraft:oak_log"), Block.from_name("minecraft:birch_log"))
        """
        # Convert strings to Block objects if needed
        if isinstance(old_block, str):
            old_block = Block.from_name(old_block)
        if isinstance(new_block, str):
            new_block = Block.from_name(new_block)
        
        old_block_name = old_block.name()
        count = 0
        
        section_range = _section_height_range(self.version)
        
        for section_y in section_range:
            section = self.get_section(section_y)
            if section is None:
                continue
            
            # Iterate through all blocks in the section
            for local_y in range(16):
                for z in range(16):
                    for x in range(16):
                        # Calculate global Y coordinate
                        global_y = section_y * 16 + local_y
                        
                        try:
                            current_block = self.get_block(x, global_y, z)
                            
                            # Check if block matches (name and properties if specified)
                            if current_block.name() == old_block_name:
                                if not old_block.properties or current_block.properties == old_block.properties:
                                    if self.replace_block_at(x, global_y, z, new_block):
                                        count += 1
                        except (IndexError, OutOfBoundsCoordinates):
                            # Skip blocks that can't be accessed
                            continue
        
        return count


    def set_biome(self, biome: Biome, x: int, y: int, z: int) -> None:
        """
        Sets the biome at given coordinates in the chunk.
        For Minecraft 1.21.1 only.

        Parameters
        ----------
        biome : Biome
            The biome to set
        int x, z
            In range of 0 to 15
        int y
            Global Y coordinate

        Raises
        ------
        OutOfBoundsCoordinates
            If coordinates are out of bounds
        """
        if x not in range(16):
            raise OutOfBoundsCoordinates(f"X ({x!r}) must be in range of 0 to 15")
        if z not in range(16):
            raise OutOfBoundsCoordinates(f"Z ({z!r}) must be in range of 0 to 15")

        section_range = _section_height_range(self.version)
        section_y = y // 16
        if section_y not in section_range:
            raise OutOfBoundsCoordinates(f"Y ({y!r}) must be in range of "
                                         f"{section_range.start * 16} to {section_range.stop * 16 - 1}")

        section = self.get_section(section_y)
        if section is None:
            section = self._create_section(section_y)

        if 'biomes' not in section:
            self._create_biomes_in_section(section)

        biomes_data = section['biomes']
        palette = biomes_data['palette']
        biome_name = biome.name()

        # Check if this is a single-biome section without data array
        if len(palette) == 1 and 'data' not in biomes_data:
            # If it's already the same biome, nothing to do
            if palette[0].value == biome_name:
                return
            # Otherwise, we need to create a data array to support multiple biomes
            # Don't just replace the palette entry as that would change the entire section

        # Find or add biome in palette
        palette_index = None
        for i, pal_biome in enumerate(palette):
            if pal_biome.value == biome_name:
                palette_index = i
                break

        if palette_index is None:
            palette_index = len(palette)
            palette.tags.append(nbt.TAG_String(value=biome_name))

        self._set_biome_in_section_data(biomes_data, palette_index, x, y % 16, z)


    def _create_biomes_in_section(self, section: nbt.TAG_Compound) -> None:
        """Create biomes structure in a section."""
        biomes = nbt.TAG_Compound(name='biomes')
        palette = nbt.TAG_List(name='palette', type=nbt.TAG_String)
        palette.tags.append(nbt.TAG_String(value='minecraft:plains'))
        biomes.tags.append(palette)
        section.tags.append(biomes)


    def _resize_biome_data_array(self, old_data: list, old_bits: int, new_bits: int) -> list:
        """
        Resize the biome data array when palette size changes.
        Extracts palette indices from old bit size and repackages them with new bit size.
        """
        # Extract all 64 palette indices from the old data array
        indices = []
        for i in range(64):
            # Calculate which long and bit offset for old format
            bit_index = i * old_bits
            state_idx = bit_index // 64
            offset = bit_index % 64
            
            if state_idx < len(old_data):
                mask = (1 << old_bits) - 1
                # Check if the value spans two longs
                if offset + old_bits <= 64:
                    palette_idx = (old_data[state_idx] >> offset) & mask
                else:
                    # Value spans two longs
                    bits_in_first = 64 - offset
                    first_part = (old_data[state_idx] >> offset) & ((1 << bits_in_first) - 1)
                    if state_idx + 1 < len(old_data):
                        bits_in_second = old_bits - bits_in_first
                        second_part = old_data[state_idx + 1] & ((1 << bits_in_second) - 1)
                        palette_idx = first_part | (second_part << bits_in_first)
                    else:
                        palette_idx = first_part
                indices.append(palette_idx)
            else:
                indices.append(0)
        
        # Repack indices with new bit size
        total_bits = 64 * new_bits
        states_count = (total_bits + 63) // 64
        new_data = [0] * states_count
        
        for i, palette_idx in enumerate(indices):
            # Calculate which long and bit offset for new format
            bit_index = i * new_bits
            state_idx = bit_index // 64
            offset = bit_index % 64
            
            if state_idx < len(new_data):
                mask = (1 << new_bits) - 1
                # Check if the value spans two longs
                if offset + new_bits <= 64:
                    new_data[state_idx] |= (palette_idx & mask) << offset
                else:
                    # Value spans two longs
                    bits_in_first = 64 - offset
                    first_part = palette_idx & ((1 << bits_in_first) - 1)
                    new_data[state_idx] |= first_part << offset
                    if state_idx + 1 < len(new_data):
                        bits_in_second = new_bits - bits_in_first
                        second_part = (palette_idx >> bits_in_first) & ((1 << bits_in_second) - 1)
                        new_data[state_idx + 1] |= second_part
        
        return new_data


    def _set_biome_in_section_data(self, biomes_data: nbt.TAG_Compound,
                                   palette_index: int, x: int, y: int, z: int) -> None:
        """
        Set biome index in section data array.
        
        Handles palette optimization: when only one biome type exists, removes the data array.
        When multiple biomes exist, creates/resizes the data array as needed.
        """
        palette = biomes_data['palette']
        
        # If palette has only one biome and we're setting to index 0, no data array needed
        if len(palette) == 1 and palette_index == 0:
            # Remove data array if it exists (optimization for uniform biomes)
            if 'data' in biomes_data:
                for i, tag in enumerate(biomes_data.tags):
                    if tag.name == 'data':
                        del biomes_data.tags[i]
                        break
            return
        
        # Calculate position in the biome array (4x4x4 blocks per biome)
        index = (y // 4) * 16 + (z // 4) * 4 + (x // 4)
        
        new_bits = max((len(palette) - 1).bit_length(), 1)

        # Check if we need to resize the data array due to palette growth
        if 'data' in biomes_data:
            old_bits = max((len(palette) - 2).bit_length(), 1) if len(palette) > 1 else 1
            if new_bits != old_bits:
                # Palette grew and needs more bits, so we need to resize the data array
                old_data = biomes_data['data'].value
                new_data = self._resize_biome_data_array(old_data, old_bits, new_bits)
                biomes_data['data'].value = new_data
        
        # Create data array if it doesn't exist
        if 'data' not in biomes_data:
            total_bits = 64 * new_bits  # 64 biome positions (4x4x4 volume)
            states_count = (total_bits + 63) // 64
            data_array = nbt.TAG_Long_Array(name='data')
            # Initialize all positions to 0 (first palette entry)
            data_array.value = [0] * states_count
            biomes_data.tags.append(data_array)

        data = biomes_data['data'].value
        
        # Calculate which long and bit offset
        bit_index = index * new_bits
        state_idx = bit_index // 64
        offset = bit_index % 64

        # Ensure data array is large enough
        required_size = state_idx + 1
        if offset + new_bits > 64:
            required_size = state_idx + 2
        
        if len(data) < required_size:
            # Create new properly sized array
            new_data = list(data) + [0] * (required_size - len(data))
            biomes_data['data'].value = new_data
            data = new_data

        mask = (1 << new_bits) - 1
        
        # Check if the value spans two longs
        if offset + new_bits <= 64:
            # Value fits in one long
            data[state_idx] &= ~(mask << offset)
            data[state_idx] |= (palette_index & mask) << offset
        else:
            # Value spans two longs - split across boundary
            bits_in_first = 64 - offset
            bits_in_second = new_bits - bits_in_first
            
            # Clear and set first part
            first_mask = (1 << bits_in_first) - 1
            data[state_idx] &= ~(first_mask << offset)
            data[state_idx] |= ((palette_index & first_mask) << offset)
            
            # Clear and set second part
            second_mask = (1 << bits_in_second) - 1
            data[state_idx + 1] &= ~second_mask
            data[state_idx + 1] |= ((palette_index >> bits_in_first) & second_mask)

    def set_chunk_biome(self, biome: Biome) -> None:
        """
        Set the entire chunk to a single biome (optimized for uniform biomes).
        
        This method efficiently sets all sections in the chunk to the same biome
        by creating a minimal palette with a single entry and no data array.

        Parameters
        ----------
        biome : Biome
            The biome to apply to the whole chunk
            
        Example
        -------
        >>> chunk.set_chunk_biome(Biome.from_name("minecraft:desert"))
        """
        biome_name = biome.name()
        section_range = _section_height_range(self.version)
        
        for section_y in section_range:
            section = self.get_section(section_y)
            if section is None:
                section = self._create_section(section_y)

            # Create or get biomes structure
            if 'biomes' not in section:
                biomes_data = nbt.TAG_Compound(name='biomes')
                palette = nbt.TAG_List(name='palette', type=nbt.TAG_String)
                palette.tags.append(nbt.TAG_String(value=biome_name))
                biomes_data.tags.append(palette)
                section.tags.append(biomes_data)
            else:
                biomes_data = section['biomes']
                palette = biomes_data['palette']
                
                # Reset palette to single biome
                palette.tags.clear()
                palette.tags.append(nbt.TAG_String(value=biome_name))
                
                # Remove data array if present (not needed for uniform biome)
                biomes_data.tags[:] = [tag for tag in biomes_data.tags if tag.name != 'data']
